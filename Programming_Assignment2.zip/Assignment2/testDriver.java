import java.io.IOException;

public class testDriver {
    public static void main(String[] args) throws IOException{
        String[] arg = new String[]{"RR", ".\\example.txt"};
        Driver.main(arg);

    }
}

// Only used for debugging