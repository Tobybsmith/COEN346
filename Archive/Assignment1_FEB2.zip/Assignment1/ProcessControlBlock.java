public class ProcessControlBlock
{
    private int mPID;
    private PROCESS_STATE mProcessState;
    
    enum PROCESS_STATE
    {
        READY,
        EXECUTE,
        TERMINATE,
        WAIT,
        NEW,
        LAST_ENUM_STATE,
    }
    
    public ProcessControlBlock(int aPID)
    {
        mPID = aPID;
        mProcessState = PROCESS_STATE.READY;
    }
    
    public int GetPID()
    {
        return mPID;
    }
    
    public PROCESS_STATE GetState()
    {
        return mProcessState;
    }
    
    public void SetState(int aState)
    {
        mProcessState = PROCESS_STATE.values()[aState];
    }
    
    @Override
    protected void finalize()
    {
        mProcessState = PROCESS_STATE.TERMINATE;
    }
}