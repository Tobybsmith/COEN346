public class InvalidPIDException extends Exception
{
    public InvalidPIDException(String aErr)
    {
        super(aErr);
    }
}